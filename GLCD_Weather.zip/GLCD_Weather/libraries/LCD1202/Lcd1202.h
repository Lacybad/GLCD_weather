/*==========================================================================================
  Created by Daniel Eichhorn and Fabrice Weinberg - ThingPulse (version 0.96" OLED display)
  Revised by AE Maker - 2020 (version Nokia 1202 LCD display)
  ==========================================================================================*/
#ifndef LCD1202_h
#define LCD1202_h

#include <Arduino.h>
#include "Lcd1202Fonts.h"

#if (defined(__AVR__))
#include <avr\pgmspace.h>
#else
#include <pgmspace.h>
#endif

// Header Values
#define JUMPTABLE_BYTES 4

#define JUMPTABLE_LSB   1
#define JUMPTABLE_SIZE  2
#define JUMPTABLE_WIDTH 3
#define JUMPTABLE_START 4

#define WIDTH_POS 0
#define HEIGHT_POS 1
#define FIRST_CHAR_POS 2
#define CHAR_NUM_POS 3

// Display commands
#define SetYAddr   0xB0
#define SetXAddr4  0x00
#define SetXAddr3  0x10

#define LCD_D         1
#define LCD_C         0

#ifndef _swap_int16_t
#define _swap_int16_t(a, b) { int16_t t = a; a = b; b = t; }
#endif

enum LCD1202_COLOR {
  WHITE = 0,
  BLACK = 1,
  INVERSE = 2
};

enum LCD1202_TEXT_ALIGNMENT {
  TEXT_ALIGN_LEFT = 0,
  TEXT_ALIGN_RIGHT = 1,
  TEXT_ALIGN_CENTER = 2,
  TEXT_ALIGN_CENTER_BOTH = 3
};

typedef byte (*FontTableLookupFunction)(const byte ch);


class Lcd1202 : public Print {
  public:
	Lcd1202(uint8_t _RES, uint8_t _CS, uint8_t _Data, uint8_t _Clock);
	Lcd1202(uint8_t _RES, uint8_t _CS, uint8_t _Data, uint8_t _Clock, uint8_t _Backlight);

	const uint16_t width(void) const { return displayWidth; };
	const uint16_t height(void) const { return displayHeight; };

    // Initialize the display
    void init();
			   
	/* Drawing functions */
	
	// Sets the color of all pixel operations
	void setColor(LCD1202_COLOR color);
	
    // Returns the current color.
    LCD1202_COLOR getColor();

    // Draw a pixel at given position
    void setPixel(int16_t x, int16_t y);
	
    // Draw a line from position 0 to position 1
    void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1);
	
    // Draw the border of a rectangle at the given location
    void drawRect(int16_t x, int16_t y, int16_t width, int16_t height);

    // Fill the rectangle
    void fillRect(int16_t x, int16_t y, int16_t width, int16_t height);
	
	// Draw the rounded rectangle
	void drawRoundRect(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r);
	
	// Fill the rounded rectangle
	void fillRoundRect(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r);

	// Draw the triangle
	void drawTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2);

	// Fill the triangle
	void fillTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2);

    // Draw the circle
    void drawCircle(int16_t x, int16_t y, int16_t radius);

    // Fill the circle
    void fillCircle(int16_t x, int16_t y, int16_t radius);
	
	// Quarter-circle drawer, used to do circles and roundrects
	void drawCircleHelper( int16_t x0, int16_t y0, int16_t r, uint8_t cornername);

	// Quarter-circle drawer with fill, used for circles and roundrects
	void fillCircleHelper(int16_t x0, int16_t y0, int16_t r, uint8_t corners, int16_t delta);

    // Draw all Quadrants specified in the quads bit mask
    void drawCircleQuads(int16_t x0, int16_t y0, int16_t radius, uint8_t quads);

    // Draw a line horizontally
    void drawHorizontalLine(int16_t x, int16_t y, int16_t length);

    // Draw a line vertically
    void drawVerticalLine(int16_t x, int16_t y, int16_t length);

    // Draws a rounded progress bar with the outer dimensions given by width and height. Progress is
    // a unsigned byte value between 0 and 100
    void drawProgressBar(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint8_t progress);
	
	// Draw a bitmap image
	void drawBitmap(int16_t x, int16_t y, int16_t w, int16_t h, const uint8_t bitmap[]);

    // Draw a bitmap in the internal image format
    void drawFastImage(int16_t x, int16_t y, int16_t width, int16_t height, const uint8_t *image);

    // Draw a XBM
    void drawXbm(int16_t x, int16_t y, int16_t width, int16_t height, const uint8_t *xbm);

    /* Text functions */
	
    // Draws a string at the given location
    void drawString(int16_t x, int16_t y, String text);

    // Draws a String with a maximum width at the given location.
    // If the given String is wider than the specified width
    // The text will be wrapped to the next line at a space or dash
    void drawStringMaxWidth(int16_t x, int16_t y, uint16_t maxLineWidth, String text);

    // Returns the width of the const char* with the current
    // font settings
    uint16_t getStringWidth(const char* text, uint16_t length);

    // Convencience method for the const char version
    uint16_t getStringWidth(String text);

    // Specifies relative to which anchor point
    // the text is rendered. Available constants:
    // TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER_BOTH
    void setTextAlignment(LCD1202_TEXT_ALIGNMENT textAlignment);

    // Sets the current font. Available default fonts
    // ArialMT_Plain_10, ArialMT_Plain_16, ArialMT_Plain_24
    void setFont(const uint8_t *fontData);

    // Set the function that will convert utf-8 to font table index
    void setFontTableLookupFunction(FontTableLookupFunction function);

    /* Display functions */

    // Inverted display
    void invertDisplay(void);

    // Convenience method to access 
    void setBrightness(uint8_t);

    // Write the buffer to the display memory
	void display(void);
	
    // Clear the local pixel buffer
    void clear(void);

    // Log buffer implementation

    // This will define the lines and characters you can
    // print to the screen. When you exeed the buffer size (lines * chars)
    // the output may be truncated due to the size constraint.
    bool setLogBuffer(uint16_t lines, uint16_t chars);

    // Draw the log buffer at position (x, y)
    void drawLogBuffer(uint16_t x, uint16_t y);

    // Get screen geometry
    uint16_t getWidth(void);
    uint16_t getHeight(void);

    // Implement needed function to be compatible with Print class
    size_t write(uint8_t c);
    size_t write(const char* s);
	   
  protected:
    volatile uint8_t RES, CS, Data, Clock, Backlight;
	
	uint8_t isBrightness = 0;

    uint16_t  displayWidth                     = 96;
    uint16_t  displayHeight                    = 68;
	uint16_t  displayBufferSize                = 864;
	uint8_t   displayBuffer[864];

	LCD1202_TEXT_ALIGNMENT   textAlignment = TEXT_ALIGN_LEFT;
    LCD1202_COLOR            color         = WHITE;

    const uint8_t          *fontData     = ArialMT_Plain_10;

    // State values for logBuffer
    uint16_t   logBufferSize                   = 0;
    uint16_t   logBufferFilled                 = 0;
    uint16_t   logBufferLine                   = 0;
    uint16_t   logBufferMaxLines               = 0;
    char      *logBuffer                       = NULL;
	
	// Send a byte to the display (low level function)
	void sendByte(byte mode, byte c);
	
	// converts utf8 characters to extended ascii
	char* utf8ascii(String s);
	
	void inline drawInternal(int16_t xMove, int16_t yMove, int16_t width, int16_t height, const uint8_t *data, uint16_t offset, uint16_t bytesInData) __attribute__((always_inline));

    void drawStringInternal(int16_t xMove, int16_t yMove, char* text, uint16_t textLength, uint16_t textWidth);

    // UTF-8 to font table index converter
    // Code form http://playground.arduino.cc/Main/Utf8ascii
    FontTableLookupFunction fontTableLookupFunction = [](const byte ch) {
      static uint8_t LASTCHAR;

      if (ch < 128) { // Standard ASCII-set 0..0x7F handling
        LASTCHAR = 0;
        return ch;
      }

      uint8_t last = LASTCHAR;   // get last char
      LASTCHAR = ch;

      switch (last) {    // conversion depnding on first UTF8-character
        case 0xC2: return (uint8_t) ch;
        case 0xC3: return (uint8_t) (ch | 0xC0);
        case 0x82: if (ch == 0xAC) return (uint8_t) 0x80;    // special case Euro-symbol
      }

      return (uint8_t) 0; // otherwise: return zero, if character has to be ignored
    };
       
};

#endif
